#!/bin/sh

# Show virtual keyboard even if no touch event
# https://github.com/maliit/keyboard/issues/104#issuecomment-1180427822
export KWIN_IM_SHOW_ALWAYS=1
